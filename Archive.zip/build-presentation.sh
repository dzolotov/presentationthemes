#!/bin/bash

# build-presentation.sh
# Универсальный скрипт для генерации презентаций из Markdown с поддержкой Mermaid и Gnuplot
# Использование: ./build-presentation.sh input.md [format] [output_file]
# Форматы: html (по умолчанию), pdf, pptx

set -e  # Останавливаемся при ошибках

# Добавляем Homebrew в PATH
export PATH="/opt/homebrew/bin:$PATH"

# Проверяем аргументы
if [ $# -lt 1 ]; then
    echo "Использование: $0 input.md [format] [output_file]"
    echo "Форматы: html, pdf, pptx"
    echo "Примеры:"
    echo "  $0 presentation.md"
    echo "  $0 presentation.md pdf"
    echo "  $0 presentation.md pptx output.pptx"
    exit 1
fi

INPUT_FILE="$1"
FORMAT="${2:-html}"  # По умолчанию HTML
INPUT_NAME=$(basename "${INPUT_FILE%.md}")
INPUT_DIR=$(dirname "$INPUT_FILE")

# Создаём директорию для результатов
GENERATED_DIR="${INPUT_DIR}/generated"
mkdir -p "$GENERATED_DIR"

# Определяем выходной файл
if [ $# -ge 3 ]; then
    OUTPUT_FILE="$3"
else
    OUTPUT_FILE="${GENERATED_DIR}/${INPUT_NAME}.${FORMAT}"
fi

# Для PDF/PPTX временный выходной файл будет в исходной директории
if [[ "$FORMAT" == "pdf" ]] || [[ "$FORMAT" == "pptx" ]]; then
    TEMP_OUTPUT_FILE="${INPUT_DIR}/${INPUT_NAME}.${FORMAT}"
else
    TEMP_OUTPUT_FILE="$OUTPUT_FILE"
fi

TEMP_FILE="${INPUT_DIR}/${INPUT_NAME}_temp.md"
RESOURCES_DIR="${GENERATED_DIR}/resources"

# Цвета для вывода
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Начинаем сборку презентации${NC}"
echo "   Входной файл: $INPUT_FILE"
echo "   Формат: $FORMAT"
echo "   Выходной файл: $OUTPUT_FILE"

# Проверяем формат
if [[ ! "$FORMAT" =~ ^(html|pdf|pptx)$ ]]; then
    echo -e "${RED}❌ Ошибка: неподдерживаемый формат '$FORMAT'${NC}"
    echo "   Поддерживаемые форматы: html, pdf, pptx"
    exit 1
fi

# Проверяем наличие входного файла
if [ ! -f "$INPUT_FILE" ]; then
    echo -e "${RED}❌ Ошибка: файл $INPUT_FILE не найден${NC}"
    exit 1
fi

# Создаём каталог resources если его нет
if [ ! -d "$RESOURCES_DIR" ]; then
    echo -e "${BLUE}📁 Создаём каталог resources${NC}"
    mkdir -p "$RESOURCES_DIR"
fi

# Копируем все изображения из локальной папки resources в generated/resources
if [ -d "${INPUT_DIR}/resources" ]; then
    echo -e "${BLUE}📸 Копируем изображения из resources в generated/resources${NC}"
    
    # Копируем webp файлы
    if ls "${INPUT_DIR}"/resources/*.webp 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.webp "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы webp файлы"
    fi
    
    # Копируем png файлы
    if ls "${INPUT_DIR}"/resources/*.png 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.png "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы png файлы"
    fi
    
    # Копируем jpg/jpeg файлы
    if ls "${INPUT_DIR}"/resources/*.jpg 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.jpg "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы jpg файлы"
    fi
    if ls "${INPUT_DIR}"/resources/*.jpeg 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.jpeg "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы jpeg файлы"
    fi
    
    # Копируем gif файлы
    if ls "${INPUT_DIR}"/resources/*.gif 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.gif "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы gif файлы"
    fi
    
    # Копируем svg файлы (если есть статичные)
    if ls "${INPUT_DIR}"/resources/*.svg 2>/dev/null | grep -q .; then
        cp "${INPUT_DIR}"/resources/*.svg "$RESOURCES_DIR/" 2>/dev/null
        echo "   Скопированы svg файлы"
    fi
    
    echo -e "${GREEN}✅ Изображения скопированы${NC}"
else
    echo -e "${BLUE}ℹ️  Папка resources не найдена${NC}"
fi

# Копируем исходный файл во временный
echo -e "${BLUE}📋 Создаём временную копию${NC}"
cp "$INPUT_FILE" "$TEMP_FILE"

# Создаём временный конфигурационный файл для Mermaid
MERMAID_CONFIG="${TEMP_FILE}.mermaid-config.json"
echo -e "${BLUE}⚙️  Создаём временную конфигурацию Mermaid${NC}"
cat > "$MERMAID_CONFIG" << 'EOF'
{
  "theme": "default",
  "themeVariables": {
    "fontSize": "14px",
    "fontFamily": "Roboto, sans-serif",
    "primaryColor": "#EEE",
    "primaryTextColor": "#333333",
    "primaryBorderColor": "#5B10B3",
    "lineColor": "#5B10B3",
    "secondaryColor": "#EEE",
    "tertiaryColor": "#f0f0f0",
    "background": "#ffffff",
    "mainBkg": "#EEE",
    "secondBkg": "#f5f5f5",
    "tertiaryBkg": "#f0f0f0",
    "nodeBkg": "#EEE",
    "textColor": "#333333",
    "labelBoxBkgColor": "#ffffff",
    "labelBoxBorderColor": "#5B10B3"
  },
  "flowchart": {
    "htmlLabels": true,
    "curve": "linear",
    "rankSpacing": 35,
    "nodeSpacing": 25,
    "padding": 15,
    "useMaxWidth": true,
    "diagramPadding": 20
  },
  "sequence": {
    "diagramMarginX": 50,
    "diagramMarginY": 10,
    "actorMargin": 50,
    "width": 150,
    "height": 65
  }
}
EOF

# Проверяем наличие mermaid блоков
if grep -q '```mermaid' "$TEMP_FILE"; then
    echo -e "${BLUE}🔍 Найдены Mermaid диаграммы${NC}"
    
    # Проверяем установлен ли mermaid-cli
    if ! command -v mmdc &> /dev/null; then
        echo -e "${BLUE}📦 Устанавливаем @mermaid-js/mermaid-cli${NC}"
        npm install -g @mermaid-js/mermaid-cli || {
            echo "   Глобальная установка не удалась, пробуем локально..."
            npm install @mermaid-js/mermaid-cli
            alias mmdc='npx mmdc'
        }
    fi
    
    # Сначала очищаем старые диаграммы для этого файла
    echo -e "${BLUE}🧹 Очищаем старые диаграммы${NC}"
    rm -f "${RESOURCES_DIR}/${INPUT_NAME}_diagram_"*.svg
    rm -f "${RESOURCES_DIR}/${INPUT_NAME}_diagram_"*.png
    
    # Счётчик для диаграмм
    COUNTER=1
    
    # Обрабатываем каждый mermaid блок
    # Используем временный маркер для отслеживания обработанных блоков
    while grep -q '```mermaid' "$TEMP_FILE"; do
        echo -e "${BLUE}   📊 Обрабатываем диаграмму #${COUNTER}${NC}"
        
        # Извлекаем первый необработанный mermaid блок
        awk '/```mermaid/{flag=1; next} /```/{if(flag) exit} flag' "$TEMP_FILE" > "temp_diagram_${COUNTER}.mmd"
        
        # Определяем тип диаграммы для имени файла
        DIAGRAM_TYPE=""
        if grep -q "graph LR\|graph RL" "temp_diagram_${COUNTER}.mmd"; then
            DIAGRAM_TYPE="_horizontal"
        elif grep -q "graph TD\|graph TB" "temp_diagram_${COUNTER}.mmd"; then
            DIAGRAM_TYPE="_vertical"
        elif grep -q "sequenceDiagram" "temp_diagram_${COUNTER}.mmd"; then
            DIAGRAM_TYPE="_sequence"
        elif grep -q "gantt" "temp_diagram_${COUNTER}.mmd"; then
            DIAGRAM_TYPE="_gantt"
        elif grep -q "flowchart" "temp_diagram_${COUNTER}.mmd"; then
            DIAGRAM_TYPE="_flowchart"
        fi
        
        # Для PPTX и PDF используем PNG, для HTML - SVG
        if [[ "$FORMAT" == "pptx" ]] || [[ "$FORMAT" == "pdf" ]]; then
            IMAGE_EXT="png"
            OUTPUT_FORMAT="--outputFormat=png"
        else
            IMAGE_EXT="svg"
            OUTPUT_FORMAT=""
        fi
        
        # Имя выходного файла - СКВОЗНАЯ НУМЕРАЦИЯ БЕЗ ТИПА
        IMAGE_FILENAME="${INPUT_NAME}_diagram_${COUNTER}.${IMAGE_EXT}"
        IMAGE_PATH="${RESOURCES_DIR}/${IMAGE_FILENAME}"
        
        # Относительный путь для вставки в Markdown
        # Для HTML нужен путь относительно generated/, для PDF/PPTX - относительно исходного файла
        if [[ "$FORMAT" == "html" ]]; then
            IMAGE_RELATIVE_PATH="resources/${IMAGE_FILENAME}"
        else
            IMAGE_RELATIVE_PATH="generated/resources/${IMAGE_FILENAME}"
        fi
        
        echo "      Путь в Markdown: $IMAGE_RELATIVE_PATH"
        
        # Генерируем изображение с помощью mermaid-cli
        echo "      Генерируем: $IMAGE_PATH"
        
        # Для вертикальных диаграмм используем другие размеры
        if [[ "$DIAGRAM_TYPE" == "_vertical" ]]; then
            if [[ "$FORMAT" == "pdf" ]]; then
                WIDTH=500
                HEIGHT=600
            else
                WIDTH=600
                HEIGHT=800
            fi
        else
            WIDTH=900
            HEIGHT=500
        fi
        
        # Для PPTX и PDF увеличиваем размеры для лучшего качества
        if [[ "$FORMAT" == "pptx" ]] || [[ "$FORMAT" == "pdf" ]]; then
            WIDTH=$((WIDTH * 2))
            HEIGHT=$((HEIGHT * 2))
        fi
        
        # Генерируем изображение
        mmdc -i "temp_diagram_${COUNTER}.mmd" \
             -o "$IMAGE_PATH" \
             -c "$MERMAID_CONFIG" \
             -w $WIDTH \
             -H $HEIGHT \
             $OUTPUT_FORMAT \
             --backgroundColor white || {
            echo -e "${RED}❌ Ошибка при генерации диаграммы #${COUNTER}${NC}"
            exit 1
        }
        
        # ВРЕМЕННО ОТКЛЮЧЕНО: добавление отступов для PDF
        # Проблема была в лишних строках текста на слайдах с page_image
        # if [[ "$FORMAT" == "pdf" ]]; then
        #     # Код добавления padding временно отключен
        # fi
        
        # Определяем ширину для разных форматов и типов диаграмм
        if [[ "$DIAGRAM_TYPE" == "_vertical" ]]; then
            PDF_WIDTH="700px"
            PPTX_WIDTH="750px"
        else
            PDF_WIDTH="850px"
            PPTX_WIDTH="900px"
        fi
        
        # Заменяем mermaid блок на изображение с центрированием
        # Используем разный подход для каждого формата
        case "$FORMAT" in
            "pdf")
                # Для PDF используем простой Markdown
                # Экранируем пробелы в пути для корректной работы с PDF
                ESCAPED_PATH=$(echo "$IMAGE_RELATIVE_PATH" | sed 's/ /%20/g')
                # Используем awk для замены первого блока mermaid
                awk -v img_path="$ESCAPED_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```mermaid/ && !replaced {
                        print ""
                        print ""
                        printf "![](%s)\n", img_path
                        print ""
                        print ""
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
            "pptx")
                # Для PPTX используем простой Markdown без стилей
                # PPTX должен центрировать изображения по умолчанию
                # Экранируем пробелы в пути
                ESCAPED_PATH=$(echo "$IMAGE_RELATIVE_PATH" | sed 's/ /%20/g')
                # Используем awk для замены первого блока mermaid
                awk -v img_path="$ESCAPED_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```mermaid/ && !replaced {
                        print ""
                        print ""
                        printf "![](%s)\n", img_path
                        print ""
                        print ""
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
            "html")
                # Для HTML используем div с flex
                # Используем awk для замены первого блока mermaid
                awk -v img_path="$IMAGE_RELATIVE_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```mermaid/ && !replaced {
                        print "<div style=\"display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;\">"
                        printf "  <img src=\"%s\" style=\"max-width: 90%%; max-height: 380px;\" />\n", img_path
                        print "</div>"
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
        esac
        
        mv "temp_output.md" "$TEMP_FILE"
        rm "temp_diagram_${COUNTER}.mmd"
        
        ((COUNTER++))
    done
    
    echo -e "${GREEN}✅ Обработано диаграмм: $((COUNTER-1))${NC}"
else
    echo -e "${BLUE}ℹ️  Mermaid диаграммы не найдены${NC}"
fi

# Проверяем наличие gnuplot блоков
if grep -q '```gnuplot' "$TEMP_FILE"; then
    echo -e "${BLUE}🔍 Найдены Gnuplot графики${NC}"
    
    # Проверяем установлен ли gnuplot
    if ! command -v gnuplot &> /dev/null; then
        echo -e "${RED}❌ Ошибка: gnuplot не установлен${NC}"
        echo "   Установите его командой: brew install gnuplot"
        exit 1
    fi
    
    # Сначала очищаем старые графики для этого файла
    echo -e "${BLUE}🧹 Очищаем старые графики${NC}"
    rm -f "${RESOURCES_DIR}/${INPUT_NAME}_plot_"*.png
    
    # Счётчик для графиков
    PLOT_COUNTER=1
    
    # Обрабатываем каждый gnuplot блок
    while grep -q '```gnuplot' "$TEMP_FILE"; do
        echo -e "${BLUE}   📊 Обрабатываем график #${PLOT_COUNTER}${NC}"
        
        # Извлекаем первый gnuplot блок
        awk '/```gnuplot/{flag=1; next} /```/{if(flag) exit} flag' "$TEMP_FILE" > "temp_plot_${PLOT_COUNTER}.plt"
        
        # Имя выходного файла PNG
        PNG_FILENAME="${INPUT_NAME}_plot_${PLOT_COUNTER}.png"
        PNG_PATH="${RESOURCES_DIR}/${PNG_FILENAME}"
        
        # Относительный путь для вставки в Markdown
        if [[ "$FORMAT" == "html" ]]; then
            PNG_RELATIVE_PATH="resources/${PNG_FILENAME}"
        else
            PNG_RELATIVE_PATH="generated/resources/${PNG_FILENAME}"
        fi
        
        echo "      Путь в Markdown: $PNG_RELATIVE_PATH"
        echo "      Генерируем: $PNG_PATH"
        
        # Создаём временный gnuplot скрипт с настройками PNG
        GNUPLOT_SCRIPT="temp_plot_${PLOT_COUNTER}_full.plt"
        cat > "$GNUPLOT_SCRIPT" << EOF
# Настройки для PNG терминала
set terminal png enhanced size 800,600 font "Arial,12" background rgb "white"
set output "${PNG_PATH}"

# Стандартные настройки для чистого вида
set border linewidth 1.5
set grid
set key outside right top

# Загружаем пользовательский код
EOF
        cat "temp_plot_${PLOT_COUNTER}.plt" >> "$GNUPLOT_SCRIPT"
        
        # Генерируем PNG с помощью gnuplot
        gnuplot "$GNUPLOT_SCRIPT" || {
            echo -e "${RED}❌ Ошибка при генерации PNG для графика #${PLOT_COUNTER}${NC}"
            exit 1
        }
        
        # Для PDF добавляем небольшой фиксированный отступ от заголовка
        if [[ "$FORMAT" == "pdf" ]]; then
            if command -v magick &> /dev/null; then
                # Фиксированный небольшой отступ
                PADDING=30
                echo "      Добавляем минимальный отступ для графика (${PADDING}px)..."
                magick "$PNG_PATH" -gravity North -background transparent -splice 0x${PADDING} "$PNG_PATH" || {
                    echo -e "${RED}❌ Ошибка при добавлении отступа${NC}"
                }
            elif command -v convert &> /dev/null; then
                # Для старой версии ImageMagick
                PADDING=30
                echo "      Добавляем минимальный отступ для графика (${PADDING}px)..."
                convert "$PNG_PATH" -gravity North -background transparent -splice 0x${PADDING} "$PNG_PATH" || {
                    echo -e "${RED}❌ Ошибка при добавлении отступа${NC}"
                }
            fi
        fi
        
        # Заменяем gnuplot блок на изображение с центрированием
        case "$FORMAT" in
            "pdf")
                # Для PDF используем простой Markdown
                ESCAPED_PATH=$(echo "$PNG_RELATIVE_PATH" | sed 's/ /%20/g')
                # Используем awk для замены первого блока gnuplot
                awk -v img_path="$ESCAPED_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```gnuplot/ && !replaced {
                        print ""
                        print ""
                        printf "![График](%s)\n", img_path
                        print ""
                        print ""
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
            "pptx")
                # Для PPTX используем простой Markdown
                ESCAPED_PATH=$(echo "$PNG_RELATIVE_PATH" | sed 's/ /%20/g')
                # Используем awk для замены первого блока gnuplot
                awk -v img_path="$ESCAPED_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```gnuplot/ && !replaced {
                        print ""
                        print ""
                        printf "![График](%s)\n", img_path
                        print ""
                        print ""
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
            "html")
                # Для HTML используем div с flex
                # Используем awk для замены первого блока gnuplot
                awk -v img_path="$PNG_RELATIVE_PATH" '
                    BEGIN { in_block = 0; replaced = 0 }
                    /```gnuplot/ && !replaced {
                        print "<div style=\"display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;\">"
                        printf "  <img src=\"%s\" style=\"max-width: 90%%; max-height: 380px;\" />\n", img_path
                        print "</div>"
                        in_block = 1
                        replaced = 1
                        next
                    }
                    /```/ && in_block {
                        in_block = 0
                        next
                    }
                    !in_block { print }
                ' "$TEMP_FILE" > "temp_output.md"
                ;;
        esac
        
        mv "temp_output.md" "$TEMP_FILE"
        rm "temp_plot_${PLOT_COUNTER}.plt" "$GNUPLOT_SCRIPT"
        
        ((PLOT_COUNTER++))
    done
    
    echo -e "${GREEN}✅ Обработано графиков: $((PLOT_COUNTER-1))${NC}"
else
    echo -e "${BLUE}ℹ️  Gnuplot графики не найдены${NC}"
fi

# Корректируем пути к изображениям и скриптам только для HTML
if [[ "$FORMAT" == "html" ]]; then
    echo -e "${BLUE}🔧 Корректируем пути к изображениям и скриптам для HTML${NC}"
    
    # Создаём временный файл для обработки
    TEMP_SED="${TEMP_FILE}.sed"
    
    # Используем perl для более надёжной обработки
    if command -v perl &> /dev/null; then
        perl -pe '
            # Markdown изображения ![alt](path) - БЕЗ SVG и БЕЗ resources/ (SVG и resources остаются как есть для HTML)
            s/!\[([^\]]*)\]\((?!http|https|\/|\.\.\/|#|resources\/)([^)]+\.(png|jpg|jpeg|gif|webp))\)/![$1](..\/\2)/g;
            
            # HTML img теги - БЕЗ SVG и БЕЗ resources/
            s/src="(?!http|https|\/|\.\.\/|#|resources\/)([^"]+\.(png|jpg|jpeg|gif|webp))"/src="..\/\1"/g;
            s/src=\x27(?!http|https|\/|\.\.\/|#|resources\/)([^\x27]+\.(png|jpg|jpeg|gif|webp))\x27/src="..\/\1"/g;
            
            # JavaScript файлы в script тегах
            s/src="(?!http|https|\/|\.\.\/|#)([^"]+\.js)"/src="..\/\1"/g;
            s/src=\x27(?!http|https|\/|\.\.\/|#)([^\x27]+\.js)\x27/src="..\/\1"/g;
        ' "$TEMP_FILE" > "$TEMP_SED"
    else
        # Альтернативный вариант с простой заменой через while read
        while IFS= read -r line; do
            # Заменяем простые случаи ![](file.ext) - БЕЗ SVG
            line=$(echo "$line" | sed -E 's/!\[([^]]*)\]\(([^/:)]+\.(png|jpg|jpeg|gif|webp))\)/![\1](..\/\2)/g')
            # Заменяем <img src="file.ext"> - БЕЗ SVG
            line=$(echo "$line" | sed -E 's/src="([^/:"][^/"]+\.(png|jpg|jpeg|gif|webp))"/src="..\/\1"/g')
            # Заменяем <script src="file.js">
            line=$(echo "$line" | sed -E 's/src="([^/:"][^/"]+\.js)"/src="..\/\1"/g')
            echo "$line"
        done < "$TEMP_FILE" > "$TEMP_SED"
    fi
    
    mv "$TEMP_SED" "$TEMP_FILE"
fi

# Для PDF/PPTX заменяем интерактивные элементы на плейсхолдеры
if [[ "$FORMAT" == "pdf" ]] || [[ "$FORMAT" == "pptx" ]]; then
    echo -e "${BLUE}🖼️  Заменяем интерактивные элементы на плейсхолдеры для $FORMAT${NC}"
    
    # Создаём временный файл для обработки
    TEMP_INTERACTIVE="${TEMP_FILE}.interactive"
    
    # Используем perl для обработки
    if command -v perl &> /dev/null; then
        perl -0777 -pe '
            # Заменяем блоки с любым id="*-viz"
            s{<div[^>]*text-align:\s*center[^>]*>.*?<svg\s+id="([^"]+)-viz".*?</div>\s*<!--[^>]*-->.*?<script[^>]*>.*?</script>}
             {![Интерактивная демонстрация $1 доступна в HTML версии]($1.png)}gs;
            
            # Удаляем все script теги
            s{<script[^>]*>.*?</script>}{}gs;
        ' "$TEMP_FILE" > "$TEMP_INTERACTIVE"
    else
        # Запасной вариант с sed
        # Заменяем блоки с svg на изображения
        sed -E '
            # Для строк с svg и id="-viz"
            /<svg[^>]*id="[^"]+-viz"/ {
                # Извлекаем имя
                s/.*id="([^"]+)-viz".*/![Интерактивная демонстрация \1 доступна в HTML версии](\1.png)/
            }
            # Удаляем строки с button
            /<button/d
            # Удаляем строки с br
            /<br>/d
            # Удаляем script теги
            /<script.*\.js/d
            /<script.*d3js/d
            /<\/script>/d
        ' "$TEMP_FILE" > "$TEMP_INTERACTIVE"
    fi
    
    mv "$TEMP_INTERACTIVE" "$TEMP_FILE"
fi

# Для PPTX упрощаем HTML-таблицы, но сохраняем структуру
if [[ "$FORMAT" == "pptx" ]]; then
    echo -e "${BLUE}📊 Упрощаем HTML-таблицы для PPTX${NC}"
    
    # Создаём временный Python скрипт для упрощения HTML-таблиц
    CONVERT_SCRIPT="${TEMP_FILE}.convert.py"
    cat > "$CONVERT_SCRIPT" << 'EOF'
import re
import sys

def simplify_html_table(html):
    """Упрощает HTML-таблицу, сохраняя базовую структуру для PPTX"""
    
    # Удаляем лишние div-обёртки, но оставляем основную структуру
    # Убираем table-container и table-wrapper, но оставляем table
    html = re.sub(r'<div class="table-container">.*?<div class="table-wrapper">', '', html, flags=re.DOTALL)
    html = re.sub(r'</div>\s*</div>$', '', html)
    
    # Удаляем column-headers div - они мешают Marp
    html = re.sub(r'<div class="column-headers">.*?</div>', '', html, flags=re.DOTALL)
    
    # Упрощаем стили таблицы
    html = re.sub(r'<table[^>]*>', '<table>', html)
    
    return html

def process_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Паттерн для поиска HTML-таблиц с классом page_twocolumn
    pattern = r'(<!-- _class: page_twocolumn -->.*?)<div class="table-container">.*?</table>.*?</div>\s*</div>'
    
    def replace_table(match):
        full_match = match.group(0)
        
        # Проверяем, что это таблица с целями
        if '<th>Цель</th>' in full_match and '<th>Смысл</th>' in full_match:
            # Извлекаем заголовки из HTML
            title_match = re.search(r'<h1>([^<]+)</h1>', full_match)
            subtitle_match = re.search(r'<h2>([^<]+)</h2>', full_match)
            
            # Извлекаем саму таблицу
            table_match = re.search(r'<table>.*?</table>', full_match, re.DOTALL)
            
            if table_match:
                result = "<!-- _class: page_twocolumn -->\n\n"
                
                # Добавляем заголовки как обычный Markdown
                if title_match:
                    result += f"# {title_match.group(1)}\n"
                if subtitle_match:
                    result += f"## {subtitle_match.group(1)}\n\n"
                
                # Добавляем упрощённую таблицу
                result += table_match.group(0) + "\n"
                
                return result
        
        # Если это не таблица целей, просто упрощаем HTML
        return simplify_html_table(full_match)
    
    # Обрабатываем все таблицы page_twocolumn
    content = re.sub(pattern, replace_table, content, flags=re.DOTALL)
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        process_file(sys.argv[1])
EOF
    
    # Запускаем Python скрипт для упрощения
    if command -v python3 &> /dev/null; then
        python3 "$CONVERT_SCRIPT" "$TEMP_FILE" || {
            echo -e "${YELLOW}⚠️  Не удалось упростить HTML-таблицы${NC}"
        }
    elif command -v python &> /dev/null; then
        python "$CONVERT_SCRIPT" "$TEMP_FILE" || {
            echo -e "${YELLOW}⚠️  Не удалось упростить HTML-таблицы${NC}"
        }
    else
        echo -e "${YELLOW}⚠️  Python не найден, HTML-таблицы не будут упрощены${NC}"
    fi
    
    # Удаляем временный скрипт
    rm -f "$CONVERT_SCRIPT"
fi

# Запускаем Marp для генерации выходного файла
echo -e "${BLUE}🎨 Генерируем $FORMAT с помощью Marp${NC}"

# Проверяем наличие Marp
MARP_CMD=""
if [ -f "/opt/homebrew/bin/marp" ]; then
    MARP_CMD="/opt/homebrew/bin/marp"
elif command -v marp &> /dev/null; then
    MARP_CMD="marp"
else
    echo -e "${RED}❌ Ошибка: Marp CLI не найден${NC}"
    echo "   Установите его командой: npm install -g @marp-team/marp-cli"
    exit 1
fi

# Определяем параметры для разных форматов
case "$FORMAT" in
    "html")
        FORMAT_ARGS="--html"
        THEME_FILE="~/Obsidian/MySecureNotes/.themes/otusnew.css"
        ;;
    "pdf")
        FORMAT_ARGS="--pdf --pdf-notes"
        THEME_FILE="~/Obsidian/MySecureNotes/.themes/otusnew.css"
        ;;
    "pptx")
        FORMAT_ARGS="--pptx --pptx-editable"
        THEME_FILE="~/Obsidian/MySecureNotes/.themes/otusnew.css"
        ;;
esac

# Генерируем выходной файл
$MARP_CMD "$TEMP_FILE" \
    $FORMAT_ARGS \
    --theme-set ~/Obsidian/MySecureNotes/.themes \
    --theme otusnew \
    --allow-local-files \
    --no-stdin \
    -o "$TEMP_OUTPUT_FILE" || {
    echo -e "${RED}❌ Ошибка при генерации $FORMAT${NC}"
    exit 1
}

# Перемещаем файл в generated для PDF/PPTX
if [[ "$FORMAT" == "pdf" ]] || [[ "$FORMAT" == "pptx" ]]; then
    echo -e "${BLUE}📦 Перемещаем $FORMAT в каталог generated${NC}"
    mv "$TEMP_OUTPUT_FILE" "$OUTPUT_FILE"
fi

# Удаляем временные файлы
echo -e "${BLUE}🧹 Очистка временных файлов${NC}"
rm -f "$TEMP_FILE" "$MERMAID_CONFIG"
rm -f temp_plot_*.plt temp_plot_*_full.plt

echo -e "${GREEN}✅ Готово!${NC}"
echo "   Файл презентации: $OUTPUT_FILE"
if [[ "$FORMAT" == "pptx" ]]; then
    echo "   PNG диаграммы и графики: $RESOURCES_DIR/"
else
    echo "   SVG диаграммы и PNG графики: $RESOURCES_DIR/"
fi
