# Test 1
```mermaid
sequenceDiagram
    A->>B: Test
```

# Test 2
```mermaid
graph TD
    A --> B
```

# Test 3
```mermaid
graph LR
    A --> B
```
EOF < /dev/null